{
    'name': "MT CRM",
    'version':'1.2',
    'summary': 'Mt crm software',
    'depends':['crm'],
    'data': [
        'security\crm_security.xml',
    ],
    'instalable': True,
    'application': True,
}